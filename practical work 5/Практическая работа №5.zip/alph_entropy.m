function [h] = alph_entropy(p)
  h =0;
  for i=1:length(p)
    if(p(i) ~= 0)
        h = h-p(i)*log2(p(i));
    end
  endfor
endfunction