function r = alph_redundancy(p)
  r = 1-(alph_entropy(p)/(log2(length(p))))
endfunction
