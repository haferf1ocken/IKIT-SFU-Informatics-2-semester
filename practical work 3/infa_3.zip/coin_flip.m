 function r = coin_flip(N)
  r = rand(N,1) >=0.5;
end