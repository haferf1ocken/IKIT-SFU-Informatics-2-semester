function h = sum_heads(r)
  h = length(r) - sum(r);
end